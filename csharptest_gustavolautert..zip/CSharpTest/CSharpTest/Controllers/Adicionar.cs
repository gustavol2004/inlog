﻿using Models;
using System.Collections.Generic;

namespace Controllers
{
    public class Adicionar
    {
        public static void InserirChassi(List<Veiculo> _veiculosList, Veiculo veiculo)
        {            
            List<Veiculo> _list = _veiculosList;

            _list.Add(veiculo);              
        }
    }
}
