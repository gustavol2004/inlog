﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controllers
{
    public class Apagar
    {
        public static void ApagarChassi(List<Veiculo> _veiculosList, string chassi)
        {
            _veiculosList.RemoveAll((x) => x.Chassi.ToUpper().Trim() == (chassi.ToUpper().Trim()));   
        }
    }
}
