﻿using Models;
using System.Collections.Generic;
using System.Linq;

namespace Controllers
{
    public class Atualizar
    {
        public static void AtualizaChassi(List<Veiculo> _veiculosList, string chassi, string cor)
        {           
            _veiculosList = _veiculosList.Where(w => w.Chassi == chassi).Select(w => { w.Cor = cor; return w; }).ToList();
        }
    }
}
