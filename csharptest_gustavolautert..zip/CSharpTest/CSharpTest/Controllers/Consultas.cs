﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Controllers
{
    public class Consultas
    {

        //static string strConexao = ConfigurationManager.ConnectionStrings["conexao"].ConnectionString;

        //public static List<Permissoes> Permissao()
        //{
        //    SqlConnection conexaoBD = new SqlConnection(strConexao);
        //    conexaoBD.Open();
        //    var resultado = conexaoBD.Query("Select permissao from Permissao");
        //    var retList = new List<Permissoes>();

        //    foreach (var res in resultado)
        //    {
        //        retList.Add(res);
        //    }

        //    conexaoBD.Close();
        //    return retList;
        //}
                
        public static void ConsultarFrota(List<Veiculo> _veiculosList)
        {
            Console.WriteLine();
            Console.WriteLine("Frota(s)");

            for (int i = 0; i < _veiculosList.Count; i++)
            {

                Console.WriteLine("Chassi: {0}, Tipo: {1}, Passageiros: {2}, Cor: {3}",
                _veiculosList[i].Chassi.PadLeft(17, ' '),
                _veiculosList[i].Tipo.PadRight(8, ' '),
                _veiculosList[i].Passageiros,
                _veiculosList[i].Cor.ToUpper()
                );
            }
        }
        public static bool ConsultarChassi(List<Veiculo> _veiculosList, string chassi)
        {
            bool tem = false;  
            var ret = _veiculosList.Where(x => x.Chassi.ToUpper().Trim() == (chassi.ToUpper().Trim())).ToList();
            foreach (var veiculo in ret)
            {
                tem = true;
            }          
            return tem;
        }
        public static void ConsultarChassiUnico(List<Veiculo> _veiculosList, string chassi)
        {       
            var ret = _veiculosList.Where(x => x.Chassi.ToUpper().Trim() == (chassi.ToUpper().Trim())).ToList();

            if (ret.Count == 0)
            {
                Console.WriteLine();
                Console.WriteLine("CHASSI: " + chassi.ToUpper().Trim() + ", NÃO LOCALIZADO!");
            }
            else
            {
                for (int i = 0; i < ret.Count; i++)
                {

                    Console.WriteLine("Chassi: {0}, Tipo: {1}, Passageiros: {2}, Cor: {3}",
                    ret[i].Chassi.PadLeft(20, ' '),
                    ret[i].Tipo.PadRight(10, ' '),
                    ret[i].Passageiros,
                    ret[i].Cor.ToUpper()
                    );
                }
            }
        }
    }
}
