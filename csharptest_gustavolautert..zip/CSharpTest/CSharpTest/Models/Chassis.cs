﻿namespace Classes
{
    public class Chassis
    {
        string chassis { get; set; }
    }
}
