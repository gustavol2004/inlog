﻿namespace Models
{
    public class Cor
    {
        int id_cor { get; set; }
        string cor { get; set; }
    }
}
