﻿namespace Models
{
    public class Frota
    {
        int id_transporte { get; set; }   
        int id_cor { get; set; }
        string chassi { get; set; }
    }
}
