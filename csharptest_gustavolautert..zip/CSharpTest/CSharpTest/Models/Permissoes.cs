﻿using System.Collections.Generic;

namespace Models
{
    public class Permissoes
    {
        string permissao { get; set; }

        public List<Permissoes> Permissao { get; set; }
    }
}
