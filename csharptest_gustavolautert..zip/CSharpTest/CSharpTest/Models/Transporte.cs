﻿namespace Models
{
    public class Transporte
    {
        int id_transporte { get; set; }
        string transporte { get; set; }
        int qtd_passageiros { get; set; }
    }
}
