﻿namespace Models
{
    public class Veiculo
    {
        public string Chassi { get; set; }
        public string Tipo { get; set; }
        public byte Passageiros { get; set; }
        public string Cor { get; set; }


        public Veiculo(string _chassi, string _tipo, byte _passageiros, string _cor)
        {
            this.Chassi = _chassi;
            this.Tipo = _tipo;
            this.Passageiros = _passageiros;
            this.Cor = _cor;
        }       
    }
}
