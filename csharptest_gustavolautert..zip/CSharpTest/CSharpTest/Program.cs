﻿using Controllers;
using DAO;
using Models;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace CSharpTest
{
    class Program
    {
        static void Main(string[] args)
        {
            String permissão = "Admin";
            String senha = "";
            Console.WriteLine("Informe o tipo de Permissão - ADMIN ou ENTER");
            permissão = Console.ReadLine();
            if (permissão.ToUpper().Trim() == "ADMIN")
            {
                Console.WriteLine("Informe a Senha ?");
                senha = Console.ReadLine();
            }

            bool done = false;
            List<Veiculo> _veiculosList = new List<Veiculo>();
            string _cor = "";
            int iSel;

            int inSel = 0;

            do
            {             
                Console.WriteLine("Selecione a opção:");
                if (permissão.ToUpper().Trim() == "ADMIN" && senha == "123")
                {
                    Console.WriteLine("\t1 -- Adicionar Veículo");
                    Console.WriteLine("\t2 -- Editar    Veículo");
                    Console.WriteLine("\t3 -- Excluir   Veículo");
                }
                Console.WriteLine("\t4 -- Listar    Veículos (Frota)");
                Console.WriteLine("\t5 -- Buscar    Veículos (Chassi)");
                Console.Write("Digite (0 para SAIR): ");
                string strSelection = Console.ReadLine();
               
                try
                {
                    iSel = 0;
                    if (permissão.ToUpper().Trim() != "ADMIN")
                    {
                        if (strSelection == "0" || strSelection == "4" || strSelection == "5")
                        {
                            inSel = int.Parse(strSelection);
                        }
                        else
                        {
                            Console.Clear();
                            inSel = 0;
                            Console.WriteLine("SEM PERMISSÃO DE ACESSO!");
                        }
                    }
                    else
                    {
                        inSel = int.Parse(strSelection);                        
                    }

                    iSel = inSel;
                }
                catch (FormatException)
                {
                    Console.Clear();
                    Console.WriteLine("\r\nSelecione uma opção ?\r\n");
                    continue;
                }
                Console.WriteLine("Selecionado:  " + iSel);

                switch (iSel)
                {
                    case 0:
                        done = true;
                        break;
                    case 1:
                        Console.Clear();
                        bool validacampos = false;
                        Console.WriteLine("1");
                        Console.WriteLine("Digite o Chassi.");
                        string _chassi = Console.ReadLine();
                        //verificar se já existe 
                        bool ret = Consultas.ConsultarChassi(_veiculosList, _chassi.ToUpper().Trim());
                        if (ret == true)
                        {
                            Console.Clear();
                            Console.WriteLine("Chassi: " + _chassi.ToUpper().Trim() + ", já existe na base!");
                            validacampos = false;
                        }
                        else
                        {
                            Console.WriteLine("Escolha o Tipo.");
                            Console.WriteLine("\t1 -- Ônibus");
                            Console.WriteLine("\t2 -- Caminhão");
                            string _tipo = "";
                            byte _passageiros = 0;
                            _cor = "";
                           string strSelect = Console.ReadLine();
                            int iSelect;
                            try
                            {
                                iSelect = int.Parse(strSelect);
                            }
                            catch (FormatException)
                            {
                                validacampos = false;
                                Console.WriteLine("\r\nSelecione um Tipo ?\r\n");
                                continue;
                            }
                            switch (iSelect)
                            {
                                case 1:
                                    _tipo = "Ônibus";
                                    _passageiros = 42;
                                    validacampos = true;
                                    break;
                                case 2:
                                    _tipo = "Caminhão";
                                    _passageiros = 2;
                                    validacampos = true;
                                    break;
                                default:
                                    validacampos = false;
                                    Console.WriteLine("Deve ser esolhido um tipo válido!\r\n", iSelect);
                                    continue;
                            }
                            Console.WriteLine("Digite a Cor.");
                            _cor = Console.ReadLine();
                            if (Regex.IsMatch(_cor, @"^[a-zA-Z]+$"))
                            {
                                validacampos = true;
                            }
                            else
                            {
                                _cor = "";
                                validacampos = false;
                                Console.WriteLine("Digite uma Cor válida!");
                            }
                            if (validacampos == true)
                            {
                                Console.Clear();
                                Console.WriteLine();         
                                Adicionar.InserirChassi(_veiculosList, new Veiculo(_chassi.ToUpper().Trim(), _tipo, _passageiros, _cor));
                                Console.WriteLine("Chassi: " + _chassi + ", inserido com sucesso");
                            }
                        }
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("2");                        
                        if (_veiculosList.Count > 0)
                        {                           
                            Consultas.ConsultarFrota(_veiculosList);
                            Console.WriteLine("\r\nInforme o chassi e a cor que deseja alterar ?\r\n");
                            Console.WriteLine("Digite o Chassi.");
                            _chassi = Console.ReadLine();
                            bool rets = Consultas.ConsultarChassi(_veiculosList, _chassi.ToUpper().Trim());
                            if (rets == true)
                            {
                                Console.WriteLine("Digite a Cor.");
                                _cor = "";
                                _cor = Console.ReadLine();
                                if (Regex.IsMatch(_cor, @"^[a-zA-Z]+$"))
                                {
                                    validacampos = true;
                                }
                                else
                                {
                                    _cor = "";
                                    validacampos = false;
                                    Console.WriteLine("Digite uma Cor válida!");
                                }
                                if (validacampos == true)
                                {
                                    Console.Clear();
                                    Atualizar.AtualizaChassi(_veiculosList, _chassi.ToUpper().Trim(), _cor);
                                    Console.WriteLine("Chassi: " + _chassi + ", alterado com sucesso");
                                }
                            }
                            else
                            {
                                Console.WriteLine("CHASSI: " + _chassi.ToUpper().Trim() + ", NÃO LOCALIZADO!");
                            }
                        }
                        else
                        {
                            Console.WriteLine("NÃO EXISTEM, VEÍCULOS CADASTRADOS!");
                        }
                        break;
                    case 3:
                        Console.Clear();
                        Console.WriteLine("3");
                        if (_veiculosList.Count > 0)
                        {
                            Consultas.ConsultarFrota(_veiculosList);
                            Console.WriteLine("\r\nInforme o chassi que deseja excluir ?\r\n");
                            Console.WriteLine("Digite o Chassi.");
                            _chassi = Console.ReadLine();
                            bool rets = Consultas.ConsultarChassi(_veiculosList, _chassi.ToUpper().Trim());
                            if (rets == true)
                            {
                                ConsoleKey responses;
                                Console.Write("Deseja realmente EXCLUIR? [S/N] ");
                                responses = Console.ReadKey(false).Key;
                                if (responses != ConsoleKey.Enter)
                                    Console.WriteLine();
                                if (responses != ConsoleKey.S && responses != ConsoleKey.N) { }
                                else
                                {
                                    if (responses == ConsoleKey.S)
                                    {
                                        Apagar.ApagarChassi(_veiculosList, _chassi.ToUpper().Trim());
                                        Console.WriteLine("Chassi: " + _chassi + ", excluído com sucesso");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("CHASSI: " + _chassi.ToUpper().Trim() + ", NÃO LOCALIZADO!");
                            }
                        }
                        else
                        {
                            Console.WriteLine("NÃO EXISTEM, VEÍCULOS CADASTRADOS!");
                        }
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("4");                        
                        if (_veiculosList.Count > 0)
                        {
                            Consultas.ConsultarFrota(_veiculosList);
                        }
                        else
                        {
                            Console.WriteLine("NÃO EXISTEM, VEÍCULOS CADASTRADOS!");
                        }
                        break;
                    case 5:
                        Console.Clear();
                        Console.WriteLine("5");
                        if (_veiculosList.Count > 0)
                        {
                            Console.WriteLine("Digite o Chassi.");
                            _chassi = Console.ReadLine();                          
                            Consultas.ConsultarChassiUnico(_veiculosList, _chassi.ToUpper().Trim());                          
                        }
                        else
                        {
                            Console.WriteLine("NÃO EXISTEM, VEÍCULOS CADASTRADOS!");
                        }
                        break;
                    default:
                        Console.WriteLine("Selecione um código válido!\r\n", iSel);
                        continue;
                }
                Console.WriteLine();


                ConsoleKey response;
                if (done == true)
                {
                    do
                    {
                        Console.Write("Deseja realmente SAIR? [S/N] ");
                        response = Console.ReadKey(false).Key;
                        if (response != ConsoleKey.Enter)
                            Console.WriteLine();

                    } while (response != ConsoleKey.S && response != ConsoleKey.N);

                    done = response == ConsoleKey.S;
                }

            } while (!done);

            Console.WriteLine("Você Saiu!");           
        }        
    }
}
